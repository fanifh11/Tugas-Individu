﻿namespace New_Ekspedisi
{
    partial class Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form));
            this.materialTabSelector1 = new MaterialSkin.Controls.MaterialTabSelector();
            this.materialTabControl1 = new MaterialSkin.Controls.MaterialTabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.pelanggan_btn = new MaterialSkin.Controls.MaterialRaisedButton();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.notelppen_box = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.notelppen_label = new MaterialSkin.Controls.MaterialLabel();
            this.alamatpenerima_box = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.alamatpenerima_label = new MaterialSkin.Controls.MaterialLabel();
            this.namapenerima_box = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.namapenerima_label = new MaterialSkin.Controls.MaterialLabel();
            this.notelppeng_box = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.notelppeng_label = new MaterialSkin.Controls.MaterialLabel();
            this.alamatpengirim_box = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.alamatpengirim_label = new MaterialSkin.Controls.MaterialLabel();
            this.namapengirim_box = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.namapengirim_label = new MaterialSkin.Controls.MaterialLabel();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.transaksi_btn = new MaterialSkin.Controls.MaterialRaisedButton();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.totaltarif_box = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.totaltarif_label = new MaterialSkin.Controls.MaterialLabel();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.asuransi_label = new MaterialSkin.Controls.MaterialLabel();
            this.materialSingleLineTextField1 = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.tarif_label = new MaterialSkin.Controls.MaterialLabel();
            this.jp_combo = new System.Windows.Forms.ComboBox();
            this.jenispengiriman_label = new MaterialSkin.Controls.MaterialLabel();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.tgltra_label = new MaterialSkin.Controls.MaterialLabel();
            this.noresi_box = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.noresi_label = new MaterialSkin.Controls.MaterialLabel();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.databarang_btn = new MaterialSkin.Controls.MaterialRaisedButton();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.berat_box = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.berat_label = new MaterialSkin.Controls.MaterialLabel();
            this.jumlah_label = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.materialLabel1 = new MaterialSkin.Controls.MaterialLabel();
            this.dll_box = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.dll_label = new MaterialSkin.Controls.MaterialLabel();
            this.jenisbrg_checklist = new System.Windows.Forms.CheckedListBox();
            this.jenisbarang_label = new MaterialSkin.Controls.MaterialLabel();
            this.idbarang_box = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.idbarang_label = new MaterialSkin.Controls.MaterialLabel();
            this.materialTabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.SuspendLayout();
            // 
            // materialTabSelector1
            // 
            this.materialTabSelector1.BaseTabControl = this.materialTabControl1;
            this.materialTabSelector1.Depth = 0;
            this.materialTabSelector1.Location = new System.Drawing.Point(-4, 78);
            this.materialTabSelector1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.materialTabSelector1.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialTabSelector1.Name = "materialTabSelector1";
            this.materialTabSelector1.Size = new System.Drawing.Size(711, 28);
            this.materialTabSelector1.TabIndex = 3;
            this.materialTabSelector1.Text = "Pelanggan";
            // 
            // materialTabControl1
            // 
            this.materialTabControl1.AccessibleName = "";
            this.materialTabControl1.Controls.Add(this.tabPage1);
            this.materialTabControl1.Controls.Add(this.tabPage2);
            this.materialTabControl1.Controls.Add(this.tabPage3);
            this.materialTabControl1.Depth = 0;
            this.materialTabControl1.Location = new System.Drawing.Point(8, 113);
            this.materialTabControl1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.materialTabControl1.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialTabControl1.Multiline = true;
            this.materialTabControl1.Name = "materialTabControl1";
            this.materialTabControl1.SelectedIndex = 0;
            this.materialTabControl1.Size = new System.Drawing.Size(684, 481);
            this.materialTabControl1.SizeMode = System.Windows.Forms.TabSizeMode.Fixed;
            this.materialTabControl1.TabIndex = 4;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.White;
            this.tabPage1.Controls.Add(this.pelanggan_btn);
            this.tabPage1.Controls.Add(this.pictureBox1);
            this.tabPage1.Controls.Add(this.notelppen_box);
            this.tabPage1.Controls.Add(this.notelppen_label);
            this.tabPage1.Controls.Add(this.alamatpenerima_box);
            this.tabPage1.Controls.Add(this.alamatpenerima_label);
            this.tabPage1.Controls.Add(this.namapenerima_box);
            this.tabPage1.Controls.Add(this.namapenerima_label);
            this.tabPage1.Controls.Add(this.notelppeng_box);
            this.tabPage1.Controls.Add(this.notelppeng_label);
            this.tabPage1.Controls.Add(this.alamatpengirim_box);
            this.tabPage1.Controls.Add(this.alamatpengirim_label);
            this.tabPage1.Controls.Add(this.namapengirim_box);
            this.tabPage1.Controls.Add(this.namapengirim_label);
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tabPage1.Size = new System.Drawing.Size(676, 452);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "pelanggan";
            // 
            // pelanggan_btn
            // 
            this.pelanggan_btn.Depth = 0;
            this.pelanggan_btn.Location = new System.Drawing.Point(20, 326);
            this.pelanggan_btn.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pelanggan_btn.MouseState = MaterialSkin.MouseState.HOVER;
            this.pelanggan_btn.Name = "pelanggan_btn";
            this.pelanggan_btn.Primary = true;
            this.pelanggan_btn.Size = new System.Drawing.Size(171, 49);
            this.pelanggan_btn.TabIndex = 13;
            this.pelanggan_btn.Text = "SIMPAN";
            this.pelanggan_btn.UseVisualStyleBackColor = true;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(20, 128);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(128, 128);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox1.TabIndex = 12;
            this.pictureBox1.TabStop = false;
            // 
            // notelppen_box
            // 
            this.notelppen_box.Depth = 0;
            this.notelppen_box.Hint = "";
            this.notelppen_box.Location = new System.Drawing.Point(245, 402);
            this.notelppen_box.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.notelppen_box.MouseState = MaterialSkin.MouseState.HOVER;
            this.notelppen_box.Name = "notelppen_box";
            this.notelppen_box.PasswordChar = '\0';
            this.notelppen_box.SelectedText = "";
            this.notelppen_box.SelectionLength = 0;
            this.notelppen_box.SelectionStart = 0;
            this.notelppen_box.Size = new System.Drawing.Size(293, 28);
            this.notelppen_box.TabIndex = 11;
            this.notelppen_box.UseSystemPasswordChar = false;
            // 
            // notelppen_label
            // 
            this.notelppen_label.AutoSize = true;
            this.notelppen_label.Depth = 0;
            this.notelppen_label.Font = new System.Drawing.Font("Roboto", 11F);
            this.notelppen_label.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.notelppen_label.Location = new System.Drawing.Point(240, 375);
            this.notelppen_label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.notelppen_label.MouseState = MaterialSkin.MouseState.HOVER;
            this.notelppen_label.Name = "notelppen_label";
            this.notelppen_label.Size = new System.Drawing.Size(118, 24);
            this.notelppen_label.TabIndex = 10;
            this.notelppen_label.Text = "No Telepon :";
            // 
            // alamatpenerima_box
            // 
            this.alamatpenerima_box.Depth = 0;
            this.alamatpenerima_box.Hint = "";
            this.alamatpenerima_box.Location = new System.Drawing.Point(245, 326);
            this.alamatpenerima_box.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.alamatpenerima_box.MouseState = MaterialSkin.MouseState.HOVER;
            this.alamatpenerima_box.Name = "alamatpenerima_box";
            this.alamatpenerima_box.PasswordChar = '\0';
            this.alamatpenerima_box.SelectedText = "";
            this.alamatpenerima_box.SelectionLength = 0;
            this.alamatpenerima_box.SelectionStart = 0;
            this.alamatpenerima_box.Size = new System.Drawing.Size(377, 28);
            this.alamatpenerima_box.TabIndex = 9;
            this.alamatpenerima_box.UseSystemPasswordChar = false;
            // 
            // alamatpenerima_label
            // 
            this.alamatpenerima_label.AutoSize = true;
            this.alamatpenerima_label.Depth = 0;
            this.alamatpenerima_label.Font = new System.Drawing.Font("Roboto", 11F);
            this.alamatpenerima_label.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.alamatpenerima_label.Location = new System.Drawing.Point(240, 299);
            this.alamatpenerima_label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.alamatpenerima_label.MouseState = MaterialSkin.MouseState.HOVER;
            this.alamatpenerima_label.Name = "alamatpenerima_label";
            this.alamatpenerima_label.Size = new System.Drawing.Size(165, 24);
            this.alamatpenerima_label.TabIndex = 8;
            this.alamatpenerima_label.Text = "Alamat Penerima :";
            // 
            // namapenerima_box
            // 
            this.namapenerima_box.Depth = 0;
            this.namapenerima_box.Hint = "";
            this.namapenerima_box.Location = new System.Drawing.Point(245, 257);
            this.namapenerima_box.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.namapenerima_box.MouseState = MaterialSkin.MouseState.HOVER;
            this.namapenerima_box.Name = "namapenerima_box";
            this.namapenerima_box.PasswordChar = '\0';
            this.namapenerima_box.SelectedText = "";
            this.namapenerima_box.SelectionLength = 0;
            this.namapenerima_box.SelectionStart = 0;
            this.namapenerima_box.Size = new System.Drawing.Size(293, 28);
            this.namapenerima_box.TabIndex = 7;
            this.namapenerima_box.UseSystemPasswordChar = false;
            // 
            // namapenerima_label
            // 
            this.namapenerima_label.AutoSize = true;
            this.namapenerima_label.Depth = 0;
            this.namapenerima_label.Font = new System.Drawing.Font("Roboto", 11F);
            this.namapenerima_label.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.namapenerima_label.Location = new System.Drawing.Point(240, 230);
            this.namapenerima_label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.namapenerima_label.MouseState = MaterialSkin.MouseState.HOVER;
            this.namapenerima_label.Name = "namapenerima_label";
            this.namapenerima_label.Size = new System.Drawing.Size(156, 24);
            this.namapenerima_label.TabIndex = 6;
            this.namapenerima_label.Text = "Nama Penerima :";
            // 
            // notelppeng_box
            // 
            this.notelppeng_box.Depth = 0;
            this.notelppeng_box.Hint = "";
            this.notelppeng_box.Location = new System.Drawing.Point(245, 187);
            this.notelppeng_box.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.notelppeng_box.MouseState = MaterialSkin.MouseState.HOVER;
            this.notelppeng_box.Name = "notelppeng_box";
            this.notelppeng_box.PasswordChar = '\0';
            this.notelppeng_box.SelectedText = "";
            this.notelppeng_box.SelectionLength = 0;
            this.notelppeng_box.SelectionStart = 0;
            this.notelppeng_box.Size = new System.Drawing.Size(293, 28);
            this.notelppeng_box.TabIndex = 5;
            this.notelppeng_box.UseSystemPasswordChar = false;
            // 
            // notelppeng_label
            // 
            this.notelppeng_label.AutoSize = true;
            this.notelppeng_label.Depth = 0;
            this.notelppeng_label.Font = new System.Drawing.Font("Roboto", 11F);
            this.notelppeng_label.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.notelppeng_label.Location = new System.Drawing.Point(240, 160);
            this.notelppeng_label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.notelppeng_label.MouseState = MaterialSkin.MouseState.HOVER;
            this.notelppeng_label.Name = "notelppeng_label";
            this.notelppeng_label.Size = new System.Drawing.Size(118, 24);
            this.notelppeng_label.TabIndex = 4;
            this.notelppeng_label.Text = "No Telepon :";
            // 
            // alamatpengirim_box
            // 
            this.alamatpengirim_box.Depth = 0;
            this.alamatpengirim_box.Hint = "";
            this.alamatpengirim_box.Location = new System.Drawing.Point(245, 128);
            this.alamatpengirim_box.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.alamatpengirim_box.MouseState = MaterialSkin.MouseState.HOVER;
            this.alamatpengirim_box.Name = "alamatpengirim_box";
            this.alamatpengirim_box.PasswordChar = '\0';
            this.alamatpengirim_box.SelectedText = "";
            this.alamatpengirim_box.SelectionLength = 0;
            this.alamatpengirim_box.SelectionStart = 0;
            this.alamatpengirim_box.Size = new System.Drawing.Size(377, 28);
            this.alamatpengirim_box.TabIndex = 3;
            this.alamatpengirim_box.UseSystemPasswordChar = false;
            // 
            // alamatpengirim_label
            // 
            this.alamatpengirim_label.AutoSize = true;
            this.alamatpengirim_label.Depth = 0;
            this.alamatpengirim_label.Font = new System.Drawing.Font("Roboto", 11F);
            this.alamatpengirim_label.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.alamatpengirim_label.Location = new System.Drawing.Point(240, 101);
            this.alamatpengirim_label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.alamatpengirim_label.MouseState = MaterialSkin.MouseState.HOVER;
            this.alamatpengirim_label.Name = "alamatpengirim_label";
            this.alamatpengirim_label.Size = new System.Drawing.Size(161, 24);
            this.alamatpengirim_label.TabIndex = 2;
            this.alamatpengirim_label.Text = "Alamat Pengirim :";
            // 
            // namapengirim_box
            // 
            this.namapengirim_box.Depth = 0;
            this.namapengirim_box.Hint = "";
            this.namapengirim_box.Location = new System.Drawing.Point(245, 69);
            this.namapengirim_box.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.namapengirim_box.MouseState = MaterialSkin.MouseState.HOVER;
            this.namapengirim_box.Name = "namapengirim_box";
            this.namapengirim_box.PasswordChar = '\0';
            this.namapengirim_box.SelectedText = "";
            this.namapengirim_box.SelectionLength = 0;
            this.namapengirim_box.SelectionStart = 0;
            this.namapengirim_box.Size = new System.Drawing.Size(293, 28);
            this.namapengirim_box.TabIndex = 1;
            this.namapengirim_box.UseSystemPasswordChar = false;
            // 
            // namapengirim_label
            // 
            this.namapengirim_label.AutoSize = true;
            this.namapengirim_label.Depth = 0;
            this.namapengirim_label.Font = new System.Drawing.Font("Roboto", 11F);
            this.namapengirim_label.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.namapengirim_label.Location = new System.Drawing.Point(240, 42);
            this.namapengirim_label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.namapengirim_label.MouseState = MaterialSkin.MouseState.HOVER;
            this.namapengirim_label.Name = "namapengirim_label";
            this.namapengirim_label.Size = new System.Drawing.Size(152, 24);
            this.namapengirim_label.TabIndex = 0;
            this.namapengirim_label.Text = "Nama Pengirim :";
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.White;
            this.tabPage2.Controls.Add(this.transaksi_btn);
            this.tabPage2.Controls.Add(this.pictureBox2);
            this.tabPage2.Controls.Add(this.totaltarif_box);
            this.tabPage2.Controls.Add(this.totaltarif_label);
            this.tabPage2.Controls.Add(this.checkBox1);
            this.tabPage2.Controls.Add(this.asuransi_label);
            this.tabPage2.Controls.Add(this.materialSingleLineTextField1);
            this.tabPage2.Controls.Add(this.tarif_label);
            this.tabPage2.Controls.Add(this.jp_combo);
            this.tabPage2.Controls.Add(this.jenispengiriman_label);
            this.tabPage2.Controls.Add(this.dateTimePicker1);
            this.tabPage2.Controls.Add(this.tgltra_label);
            this.tabPage2.Controls.Add(this.noresi_box);
            this.tabPage2.Controls.Add(this.noresi_label);
            this.tabPage2.Location = new System.Drawing.Point(4, 25);
            this.tabPage2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tabPage2.Size = new System.Drawing.Size(676, 452);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "transaksi";
            // 
            // transaksi_btn
            // 
            this.transaksi_btn.Depth = 0;
            this.transaksi_btn.Location = new System.Drawing.Point(21, 318);
            this.transaksi_btn.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.transaksi_btn.MouseState = MaterialSkin.MouseState.HOVER;
            this.transaksi_btn.Name = "transaksi_btn";
            this.transaksi_btn.Primary = true;
            this.transaksi_btn.Size = new System.Drawing.Size(141, 43);
            this.transaksi_btn.TabIndex = 13;
            this.transaksi_btn.Text = "SIMPAN";
            this.transaksi_btn.UseVisualStyleBackColor = true;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(8, 126);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(175, 160);
            this.pictureBox2.TabIndex = 12;
            this.pictureBox2.TabStop = false;
            // 
            // totaltarif_box
            // 
            this.totaltarif_box.Depth = 0;
            this.totaltarif_box.Hint = "";
            this.totaltarif_box.Location = new System.Drawing.Point(332, 368);
            this.totaltarif_box.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.totaltarif_box.MouseState = MaterialSkin.MouseState.HOVER;
            this.totaltarif_box.Name = "totaltarif_box";
            this.totaltarif_box.PasswordChar = '\0';
            this.totaltarif_box.SelectedText = "";
            this.totaltarif_box.SelectionLength = 0;
            this.totaltarif_box.SelectionStart = 0;
            this.totaltarif_box.Size = new System.Drawing.Size(284, 28);
            this.totaltarif_box.TabIndex = 11;
            this.totaltarif_box.Tag = "";
            this.totaltarif_box.UseSystemPasswordChar = false;
            // 
            // totaltarif_label
            // 
            this.totaltarif_label.AutoSize = true;
            this.totaltarif_label.Depth = 0;
            this.totaltarif_label.Font = new System.Drawing.Font("Roboto", 11F);
            this.totaltarif_label.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.totaltarif_label.Location = new System.Drawing.Point(208, 373);
            this.totaltarif_label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.totaltarif_label.MouseState = MaterialSkin.MouseState.HOVER;
            this.totaltarif_label.Name = "totaltarif_label";
            this.totaltarif_label.Size = new System.Drawing.Size(107, 24);
            this.totaltarif_label.TabIndex = 10;
            this.totaltarif_label.Text = "Total Tarif :";
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(483, 329);
            this.checkBox1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(18, 17);
            this.checkBox1.TabIndex = 9;
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // asuransi_label
            // 
            this.asuransi_label.AutoSize = true;
            this.asuransi_label.Depth = 0;
            this.asuransi_label.Font = new System.Drawing.Font("Roboto", 11F);
            this.asuransi_label.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.asuransi_label.Location = new System.Drawing.Point(209, 324);
            this.asuransi_label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.asuransi_label.MouseState = MaterialSkin.MouseState.HOVER;
            this.asuransi_label.Name = "asuransi_label";
            this.asuransi_label.Size = new System.Drawing.Size(253, 24);
            this.asuransi_label.TabIndex = 8;
            this.asuransi_label.Text = "Biaya Asuransi  (Rp 5.000,-) :";
            // 
            // materialSingleLineTextField1
            // 
            this.materialSingleLineTextField1.Depth = 0;
            this.materialSingleLineTextField1.Hint = "";
            this.materialSingleLineTextField1.Location = new System.Drawing.Point(280, 278);
            this.materialSingleLineTextField1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.materialSingleLineTextField1.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialSingleLineTextField1.Name = "materialSingleLineTextField1";
            this.materialSingleLineTextField1.PasswordChar = '\0';
            this.materialSingleLineTextField1.SelectedText = "";
            this.materialSingleLineTextField1.SelectionLength = 0;
            this.materialSingleLineTextField1.SelectionStart = 0;
            this.materialSingleLineTextField1.Size = new System.Drawing.Size(336, 28);
            this.materialSingleLineTextField1.TabIndex = 7;
            this.materialSingleLineTextField1.Tag = "";
            this.materialSingleLineTextField1.UseSystemPasswordChar = false;
            // 
            // tarif_label
            // 
            this.tarif_label.AutoSize = true;
            this.tarif_label.Depth = 0;
            this.tarif_label.Font = new System.Drawing.Font("Roboto", 11F);
            this.tarif_label.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.tarif_label.Location = new System.Drawing.Point(208, 283);
            this.tarif_label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.tarif_label.MouseState = MaterialSkin.MouseState.HOVER;
            this.tarif_label.Name = "tarif_label";
            this.tarif_label.Size = new System.Drawing.Size(59, 24);
            this.tarif_label.TabIndex = 6;
            this.tarif_label.Text = "Tarif :";
            // 
            // jp_combo
            // 
            this.jp_combo.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.jp_combo.FormattingEnabled = true;
            this.jp_combo.Items.AddRange(new object[] {
            "Reguler",
            "Kilat",
            "Express"});
            this.jp_combo.Location = new System.Drawing.Point(213, 231);
            this.jp_combo.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.jp_combo.Name = "jp_combo";
            this.jp_combo.Size = new System.Drawing.Size(265, 32);
            this.jp_combo.TabIndex = 5;
            this.jp_combo.SelectedIndexChanged += new System.EventHandler(this.JP_combo);
            // 
            // jenispengiriman_label
            // 
            this.jenispengiriman_label.AutoSize = true;
            this.jenispengiriman_label.Depth = 0;
            this.jenispengiriman_label.Font = new System.Drawing.Font("Roboto", 11F);
            this.jenispengiriman_label.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.jenispengiriman_label.Location = new System.Drawing.Point(208, 204);
            this.jenispengiriman_label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.jenispengiriman_label.MouseState = MaterialSkin.MouseState.HOVER;
            this.jenispengiriman_label.Name = "jenispengiriman_label";
            this.jenispengiriman_label.Size = new System.Drawing.Size(171, 24);
            this.jenispengiriman_label.TabIndex = 4;
            this.jenispengiriman_label.Text = "Jenis Pengiriman : ";
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker1.Location = new System.Drawing.Point(213, 153);
            this.dateTimePicker1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(265, 29);
            this.dateTimePicker1.TabIndex = 3;
            // 
            // tgltra_label
            // 
            this.tgltra_label.AutoSize = true;
            this.tgltra_label.Depth = 0;
            this.tgltra_label.Font = new System.Drawing.Font("Roboto", 11F);
            this.tgltra_label.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.tgltra_label.Location = new System.Drawing.Point(208, 126);
            this.tgltra_label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.tgltra_label.MouseState = MaterialSkin.MouseState.HOVER;
            this.tgltra_label.Name = "tgltra_label";
            this.tgltra_label.Size = new System.Drawing.Size(175, 24);
            this.tgltra_label.TabIndex = 2;
            this.tgltra_label.Text = "Tanggal Transaksi :";
            // 
            // noresi_box
            // 
            this.noresi_box.Depth = 0;
            this.noresi_box.Hint = "";
            this.noresi_box.Location = new System.Drawing.Point(213, 82);
            this.noresi_box.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.noresi_box.MouseState = MaterialSkin.MouseState.HOVER;
            this.noresi_box.Name = "noresi_box";
            this.noresi_box.PasswordChar = '\0';
            this.noresi_box.SelectedText = "";
            this.noresi_box.SelectionLength = 0;
            this.noresi_box.SelectionStart = 0;
            this.noresi_box.Size = new System.Drawing.Size(403, 28);
            this.noresi_box.TabIndex = 1;
            this.noresi_box.UseSystemPasswordChar = false;
            this.noresi_box.Click += new System.EventHandler(this.noresi_box_Click);
            // 
            // noresi_label
            // 
            this.noresi_label.AutoSize = true;
            this.noresi_label.Depth = 0;
            this.noresi_label.Font = new System.Drawing.Font("Roboto", 11F);
            this.noresi_label.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.noresi_label.Location = new System.Drawing.Point(208, 55);
            this.noresi_label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.noresi_label.MouseState = MaterialSkin.MouseState.HOVER;
            this.noresi_label.Name = "noresi_label";
            this.noresi_label.Size = new System.Drawing.Size(92, 24);
            this.noresi_label.TabIndex = 0;
            this.noresi_label.Text = "No Resi : ";
            // 
            // tabPage3
            // 
            this.tabPage3.BackColor = System.Drawing.Color.White;
            this.tabPage3.Controls.Add(this.databarang_btn);
            this.tabPage3.Controls.Add(this.pictureBox3);
            this.tabPage3.Controls.Add(this.berat_box);
            this.tabPage3.Controls.Add(this.berat_label);
            this.tabPage3.Controls.Add(this.jumlah_label);
            this.tabPage3.Controls.Add(this.materialLabel1);
            this.tabPage3.Controls.Add(this.dll_box);
            this.tabPage3.Controls.Add(this.dll_label);
            this.tabPage3.Controls.Add(this.jenisbrg_checklist);
            this.tabPage3.Controls.Add(this.jenisbarang_label);
            this.tabPage3.Controls.Add(this.idbarang_box);
            this.tabPage3.Controls.Add(this.idbarang_label);
            this.tabPage3.Location = new System.Drawing.Point(4, 25);
            this.tabPage3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tabPage3.Size = new System.Drawing.Size(676, 452);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "data barang";
            // 
            // databarang_btn
            // 
            this.databarang_btn.Depth = 0;
            this.databarang_btn.Location = new System.Drawing.Point(29, 279);
            this.databarang_btn.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.databarang_btn.MouseState = MaterialSkin.MouseState.HOVER;
            this.databarang_btn.Name = "databarang_btn";
            this.databarang_btn.Primary = true;
            this.databarang_btn.Size = new System.Drawing.Size(129, 60);
            this.databarang_btn.TabIndex = 11;
            this.databarang_btn.Text = "SIMPAN";
            this.databarang_btn.UseVisualStyleBackColor = true;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(8, 89);
            this.pictureBox3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(172, 170);
            this.pictureBox3.TabIndex = 10;
            this.pictureBox3.TabStop = false;
            // 
            // berat_box
            // 
            this.berat_box.Depth = 0;
            this.berat_box.Hint = "";
            this.berat_box.Location = new System.Drawing.Point(316, 320);
            this.berat_box.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.berat_box.MouseState = MaterialSkin.MouseState.HOVER;
            this.berat_box.Name = "berat_box";
            this.berat_box.PasswordChar = '\0';
            this.berat_box.SelectedText = "";
            this.berat_box.SelectionLength = 0;
            this.berat_box.SelectionStart = 0;
            this.berat_box.Size = new System.Drawing.Size(64, 28);
            this.berat_box.TabIndex = 9;
            this.berat_box.UseSystemPasswordChar = false;
            // 
            // berat_label
            // 
            this.berat_label.AutoSize = true;
            this.berat_label.Depth = 0;
            this.berat_label.Font = new System.Drawing.Font("Roboto", 11F);
            this.berat_label.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.berat_label.Location = new System.Drawing.Point(240, 320);
            this.berat_label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.berat_label.MouseState = MaterialSkin.MouseState.HOVER;
            this.berat_label.Name = "berat_label";
            this.berat_label.Size = new System.Drawing.Size(64, 24);
            this.berat_label.TabIndex = 8;
            this.berat_label.Text = "Berat :";
            // 
            // jumlah_label
            // 
            this.jumlah_label.Depth = 0;
            this.jumlah_label.Hint = "";
            this.jumlah_label.Location = new System.Drawing.Point(336, 273);
            this.jumlah_label.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.jumlah_label.MouseState = MaterialSkin.MouseState.HOVER;
            this.jumlah_label.Name = "jumlah_label";
            this.jumlah_label.PasswordChar = '\0';
            this.jumlah_label.SelectedText = "";
            this.jumlah_label.SelectionLength = 0;
            this.jumlah_label.SelectionStart = 0;
            this.jumlah_label.Size = new System.Drawing.Size(44, 28);
            this.jumlah_label.TabIndex = 7;
            this.jumlah_label.UseSystemPasswordChar = false;
            // 
            // materialLabel1
            // 
            this.materialLabel1.AutoSize = true;
            this.materialLabel1.Depth = 0;
            this.materialLabel1.Font = new System.Drawing.Font("Roboto", 11F);
            this.materialLabel1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialLabel1.Location = new System.Drawing.Point(240, 273);
            this.materialLabel1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.materialLabel1.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel1.Name = "materialLabel1";
            this.materialLabel1.Size = new System.Drawing.Size(82, 24);
            this.materialLabel1.TabIndex = 6;
            this.materialLabel1.Text = "Jumlah :";
            // 
            // dll_box
            // 
            this.dll_box.Depth = 0;
            this.dll_box.Hint = "";
            this.dll_box.Location = new System.Drawing.Point(385, 230);
            this.dll_box.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dll_box.MouseState = MaterialSkin.MouseState.HOVER;
            this.dll_box.Name = "dll_box";
            this.dll_box.PasswordChar = '\0';
            this.dll_box.SelectedText = "";
            this.dll_box.SelectionLength = 0;
            this.dll_box.SelectionStart = 0;
            this.dll_box.Size = new System.Drawing.Size(245, 28);
            this.dll_box.TabIndex = 5;
            this.dll_box.UseSystemPasswordChar = false;
            // 
            // dll_label
            // 
            this.dll_label.AutoSize = true;
            this.dll_label.Depth = 0;
            this.dll_label.Font = new System.Drawing.Font("Roboto", 11F);
            this.dll_label.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.dll_label.Location = new System.Drawing.Point(240, 230);
            this.dll_label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.dll_label.MouseState = MaterialSkin.MouseState.HOVER;
            this.dll_label.Name = "dll_label";
            this.dll_label.Size = new System.Drawing.Size(130, 24);
            this.dll_label.TabIndex = 4;
            this.dll_label.Text = "*Dan lain-lain :";
            // 
            // jenisbrg_checklist
            // 
            this.jenisbrg_checklist.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.jenisbrg_checklist.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.jenisbrg_checklist.FormattingEnabled = true;
            this.jenisbrg_checklist.Items.AddRange(new object[] {
            "Buku",
            "Elektronik",
            "Makanan / Minuman",
            "Baju",
            "Dan lain-lain"});
            this.jenisbrg_checklist.Location = new System.Drawing.Point(385, 100);
            this.jenisbrg_checklist.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.jenisbrg_checklist.Name = "jenisbrg_checklist";
            this.jenisbrg_checklist.Size = new System.Drawing.Size(160, 105);
            this.jenisbrg_checklist.TabIndex = 3;
            // 
            // jenisbarang_label
            // 
            this.jenisbarang_label.AutoSize = true;
            this.jenisbarang_label.Depth = 0;
            this.jenisbarang_label.Font = new System.Drawing.Font("Roboto", 11F);
            this.jenisbarang_label.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.jenisbarang_label.Location = new System.Drawing.Point(240, 100);
            this.jenisbarang_label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.jenisbarang_label.MouseState = MaterialSkin.MouseState.HOVER;
            this.jenisbarang_label.Name = "jenisbarang_label";
            this.jenisbarang_label.Size = new System.Drawing.Size(129, 24);
            this.jenisbarang_label.TabIndex = 2;
            this.jenisbarang_label.Text = "Jenis Barang :";
            // 
            // idbarang_box
            // 
            this.idbarang_box.Depth = 0;
            this.idbarang_box.Hint = "";
            this.idbarang_box.Location = new System.Drawing.Point(357, 59);
            this.idbarang_box.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.idbarang_box.MouseState = MaterialSkin.MouseState.HOVER;
            this.idbarang_box.Name = "idbarang_box";
            this.idbarang_box.PasswordChar = '\0';
            this.idbarang_box.SelectedText = "";
            this.idbarang_box.SelectionLength = 0;
            this.idbarang_box.SelectionStart = 0;
            this.idbarang_box.Size = new System.Drawing.Size(273, 28);
            this.idbarang_box.TabIndex = 1;
            this.idbarang_box.UseSystemPasswordChar = false;
            // 
            // idbarang_label
            // 
            this.idbarang_label.AutoSize = true;
            this.idbarang_label.Depth = 0;
            this.idbarang_label.Font = new System.Drawing.Font("Roboto", 11F);
            this.idbarang_label.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.idbarang_label.Location = new System.Drawing.Point(240, 59);
            this.idbarang_label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.idbarang_label.MouseState = MaterialSkin.MouseState.HOVER;
            this.idbarang_label.Name = "idbarang_label";
            this.idbarang_label.Size = new System.Drawing.Size(101, 24);
            this.idbarang_label.TabIndex = 0;
            this.idbarang_label.Text = "ID Barang :";
            // 
            // Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(700, 597);
            this.Controls.Add(this.materialTabControl1);
            this.Controls.Add(this.materialTabSelector1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "Form";
            this.Text = "Jasa Ekspedisi Barang";
            this.Load += new System.EventHandler(this.Form_Load);
            this.materialTabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private MaterialSkin.Controls.MaterialTabSelector materialTabSelector1;
        private MaterialSkin.Controls.MaterialTabControl materialTabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage3;
        private MaterialSkin.Controls.MaterialLabel namapengirim_label;
        private MaterialSkin.Controls.MaterialSingleLineTextField namapengirim_box;
        private MaterialSkin.Controls.MaterialSingleLineTextField notelppeng_box;
        private MaterialSkin.Controls.MaterialLabel notelppeng_label;
        private MaterialSkin.Controls.MaterialSingleLineTextField alamatpengirim_box;
        private MaterialSkin.Controls.MaterialLabel alamatpengirim_label;
        private MaterialSkin.Controls.MaterialLabel notelppen_label;
        private MaterialSkin.Controls.MaterialSingleLineTextField alamatpenerima_box;
        private MaterialSkin.Controls.MaterialLabel alamatpenerima_label;
        private MaterialSkin.Controls.MaterialSingleLineTextField namapenerima_box;
        private MaterialSkin.Controls.MaterialLabel namapenerima_label;
        private MaterialSkin.Controls.MaterialSingleLineTextField notelppen_box;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TabPage tabPage2;
        private MaterialSkin.Controls.MaterialLabel tgltra_label;
        private MaterialSkin.Controls.MaterialSingleLineTextField noresi_box;
        private MaterialSkin.Controls.MaterialLabel noresi_label;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private MaterialSkin.Controls.MaterialLabel jenispengiriman_label;
        private System.Windows.Forms.ComboBox jp_combo;
        private MaterialSkin.Controls.MaterialLabel tarif_label;
        private MaterialSkin.Controls.MaterialSingleLineTextField materialSingleLineTextField1;
        private System.Windows.Forms.CheckBox checkBox1;
        private MaterialSkin.Controls.MaterialLabel asuransi_label;
        private MaterialSkin.Controls.MaterialSingleLineTextField totaltarif_box;
        private MaterialSkin.Controls.MaterialLabel totaltarif_label;
        private System.Windows.Forms.PictureBox pictureBox2;
        private MaterialSkin.Controls.MaterialLabel idbarang_label;
        private MaterialSkin.Controls.MaterialLabel jenisbarang_label;
        private MaterialSkin.Controls.MaterialSingleLineTextField idbarang_box;
        private System.Windows.Forms.CheckedListBox jenisbrg_checklist;
        private MaterialSkin.Controls.MaterialLabel dll_label;
        private MaterialSkin.Controls.MaterialSingleLineTextField berat_box;
        private MaterialSkin.Controls.MaterialLabel berat_label;
        private MaterialSkin.Controls.MaterialSingleLineTextField jumlah_label;
        private MaterialSkin.Controls.MaterialLabel materialLabel1;
        private MaterialSkin.Controls.MaterialSingleLineTextField dll_box;
        private System.Windows.Forms.PictureBox pictureBox3;
        private MaterialSkin.Controls.MaterialRaisedButton pelanggan_btn;
        private MaterialSkin.Controls.MaterialRaisedButton transaksi_btn;
        private MaterialSkin.Controls.MaterialRaisedButton databarang_btn;
    }
}

