﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace New_Ekspedisi
{
    public partial class Form : MaterialSkin.Controls.MaterialForm
    {
        public Form()
        {
            InitializeComponent();
        }

        private void Form_Load(object sender, EventArgs e)
        {

        }

        private void noresi_box_Click(object sender, EventArgs e)
        {

        }

        private void JP_combo(object sender, EventArgs e)
        {

        }
    }
}
