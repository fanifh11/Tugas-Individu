<?=template_header('Place Order')?>

<div class="placeorder content-wrapper">
    <h1>Pesanan Sudah Diproses</h1>
    <p>Terimakasih Telah Berbelanja di Toko Kami , Untuk Struk Silahkan Cek di Email Anda.</p><br>
   <center> <img src="imgs/thx.png" style="align-content: center;"  width="300px"  alt=""></center><br>
</div>

<?=template_footer()?>