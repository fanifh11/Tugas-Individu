﻿namespace Kalkulator_Baru
{
    partial class Kalkulator
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Kalkulator));
            this.num1 = new System.Windows.Forms.Button();
            this.num2 = new System.Windows.Forms.Button();
            this.num3 = new System.Windows.Forms.Button();
            this.num4 = new System.Windows.Forms.Button();
            this.num5 = new System.Windows.Forms.Button();
            this.num7 = new System.Windows.Forms.Button();
            this.num8 = new System.Windows.Forms.Button();
            this.num9 = new System.Windows.Forms.Button();
            this.num0 = new System.Windows.Forms.Button();
            this.coma = new System.Windows.Forms.Button();
            this.hasil = new System.Windows.Forms.Button();
            this.plus = new System.Windows.Forms.Button();
            this.kurang = new System.Windows.Forms.Button();
            this.kali = new System.Windows.Forms.Button();
            this.bagi = new System.Windows.Forms.Button();
            this.hapus1 = new System.Windows.Forms.Button();
            this.delete = new System.Windows.Forms.Button();
            this.Display = new System.Windows.Forms.TextBox();
            this.num6 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.plusmin = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // num1
            // 
            this.num1.Location = new System.Drawing.Point(12, 275);
            this.num1.Name = "num1";
            this.num1.Size = new System.Drawing.Size(64, 57);
            this.num1.TabIndex = 0;
            this.num1.Text = "1";
            this.num1.UseVisualStyleBackColor = true;
            this.num1.Click += new System.EventHandler(this.num1_click);
            // 
            // num2
            // 
            this.num2.Location = new System.Drawing.Point(82, 275);
            this.num2.Name = "num2";
            this.num2.Size = new System.Drawing.Size(64, 57);
            this.num2.TabIndex = 1;
            this.num2.Text = "2";
            this.num2.UseVisualStyleBackColor = true;
            this.num2.Click += new System.EventHandler(this.num2_click);
            // 
            // num3
            // 
            this.num3.Location = new System.Drawing.Point(152, 275);
            this.num3.Name = "num3";
            this.num3.Size = new System.Drawing.Size(64, 57);
            this.num3.TabIndex = 2;
            this.num3.Text = "3";
            this.num3.UseVisualStyleBackColor = true;
            this.num3.Click += new System.EventHandler(this.num3_click);
            // 
            // num4
            // 
            this.num4.Location = new System.Drawing.Point(12, 212);
            this.num4.Name = "num4";
            this.num4.Size = new System.Drawing.Size(64, 57);
            this.num4.TabIndex = 3;
            this.num4.Text = "4";
            this.num4.UseVisualStyleBackColor = true;
            this.num4.Click += new System.EventHandler(this.num4_click);
            // 
            // num5
            // 
            this.num5.Location = new System.Drawing.Point(82, 212);
            this.num5.Name = "num5";
            this.num5.Size = new System.Drawing.Size(64, 57);
            this.num5.TabIndex = 4;
            this.num5.Text = "5";
            this.num5.UseVisualStyleBackColor = true;
            this.num5.Click += new System.EventHandler(this.num5_click);
            // 
            // num7
            // 
            this.num7.Location = new System.Drawing.Point(12, 149);
            this.num7.Name = "num7";
            this.num7.Size = new System.Drawing.Size(64, 57);
            this.num7.TabIndex = 6;
            this.num7.Text = "7";
            this.num7.UseVisualStyleBackColor = true;
            this.num7.Click += new System.EventHandler(this.num7_click);
            // 
            // num8
            // 
            this.num8.Location = new System.Drawing.Point(82, 149);
            this.num8.Name = "num8";
            this.num8.Size = new System.Drawing.Size(64, 57);
            this.num8.TabIndex = 7;
            this.num8.Text = "8";
            this.num8.UseVisualStyleBackColor = true;
            this.num8.Click += new System.EventHandler(this.num8_click);
            // 
            // num9
            // 
            this.num9.Location = new System.Drawing.Point(152, 149);
            this.num9.Name = "num9";
            this.num9.Size = new System.Drawing.Size(64, 57);
            this.num9.TabIndex = 8;
            this.num9.Text = "9";
            this.num9.UseVisualStyleBackColor = true;
            this.num9.Click += new System.EventHandler(this.num9_click);
            // 
            // num0
            // 
            this.num0.Location = new System.Drawing.Point(82, 338);
            this.num0.Name = "num0";
            this.num0.Size = new System.Drawing.Size(64, 57);
            this.num0.TabIndex = 9;
            this.num0.Text = "0";
            this.num0.UseVisualStyleBackColor = true;
            this.num0.Click += new System.EventHandler(this.num0_click);
            // 
            // coma
            // 
            this.coma.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.coma.Location = new System.Drawing.Point(152, 338);
            this.coma.Name = "coma";
            this.coma.Size = new System.Drawing.Size(64, 57);
            this.coma.TabIndex = 10;
            this.coma.Text = ".";
            this.coma.UseVisualStyleBackColor = false;
            this.coma.Click += new System.EventHandler(this.btnComa_click);
            // 
            // hasil
            // 
            this.hasil.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.hasil.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.hasil.Location = new System.Drawing.Point(222, 275);
            this.hasil.Name = "hasil";
            this.hasil.Size = new System.Drawing.Size(64, 120);
            this.hasil.TabIndex = 11;
            this.hasil.Text = "=";
            this.hasil.UseVisualStyleBackColor = false;
            this.hasil.Click += new System.EventHandler(this.btnHasil_click);
            // 
            // plus
            // 
            this.plus.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.plus.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.plus.Location = new System.Drawing.Point(222, 212);
            this.plus.Name = "plus";
            this.plus.Size = new System.Drawing.Size(64, 57);
            this.plus.TabIndex = 12;
            this.plus.Text = "+";
            this.plus.UseVisualStyleBackColor = false;
            this.plus.Click += new System.EventHandler(this.btnJumlah_click);
            // 
            // kurang
            // 
            this.kurang.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.kurang.Location = new System.Drawing.Point(222, 149);
            this.kurang.Name = "kurang";
            this.kurang.Size = new System.Drawing.Size(64, 57);
            this.kurang.TabIndex = 13;
            this.kurang.Text = "-";
            this.kurang.UseVisualStyleBackColor = false;
            this.kurang.Click += new System.EventHandler(this.btnKurang_click);
            // 
            // kali
            // 
            this.kali.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.kali.Location = new System.Drawing.Point(222, 86);
            this.kali.Name = "kali";
            this.kali.Size = new System.Drawing.Size(64, 57);
            this.kali.TabIndex = 14;
            this.kali.Text = "x";
            this.kali.UseVisualStyleBackColor = false;
            this.kali.Click += new System.EventHandler(this.btnKali_click);
            // 
            // bagi
            // 
            this.bagi.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.bagi.Location = new System.Drawing.Point(152, 86);
            this.bagi.Name = "bagi";
            this.bagi.Size = new System.Drawing.Size(64, 57);
            this.bagi.TabIndex = 15;
            this.bagi.Text = "/";
            this.bagi.UseVisualStyleBackColor = false;
            this.bagi.Click += new System.EventHandler(this.btnBagi_click);
            // 
            // hapus1
            // 
            this.hapus1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.hapus1.Location = new System.Drawing.Point(82, 86);
            this.hapus1.Name = "hapus1";
            this.hapus1.Size = new System.Drawing.Size(64, 57);
            this.hapus1.TabIndex = 16;
            this.hapus1.Text = "Backspace";
            this.hapus1.UseVisualStyleBackColor = false;
            this.hapus1.Click += new System.EventHandler(this.btnBackspace_click);
            // 
            // delete
            // 
            this.delete.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.delete.Location = new System.Drawing.Point(12, 86);
            this.delete.Name = "delete";
            this.delete.Size = new System.Drawing.Size(64, 57);
            this.delete.TabIndex = 17;
            this.delete.Text = "C";
            this.delete.UseVisualStyleBackColor = false;
            this.delete.Click += new System.EventHandler(this.btnClear_click);
            // 
            // Display
            // 
            this.Display.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Display.Location = new System.Drawing.Point(12, 22);
            this.Display.Multiline = true;
            this.Display.Name = "Display";
            this.Display.Size = new System.Drawing.Size(274, 50);
            this.Display.TabIndex = 18;
            this.Display.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.Display.UseWaitCursor = true;
            this.Display.TextChanged += new System.EventHandler(this.Display_TextChanged);
            // 
            // num6
            // 
            this.num6.Location = new System.Drawing.Point(152, 212);
            this.num6.Name = "num6";
            this.num6.Size = new System.Drawing.Size(64, 57);
            this.num6.TabIndex = 19;
            this.num6.Text = "6";
            this.num6.UseVisualStyleBackColor = true;
            this.num6.Click += new System.EventHandler(this.num6_click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(14, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 20);
            this.label1.TabIndex = 20;
            // 
            // plusmin
            // 
            this.plusmin.BackColor = System.Drawing.Color.AntiqueWhite;
            this.plusmin.Location = new System.Drawing.Point(12, 338);
            this.plusmin.Name = "plusmin";
            this.plusmin.Size = new System.Drawing.Size(64, 57);
            this.plusmin.TabIndex = 21;
            this.plusmin.Text = "+/-";
            this.plusmin.UseVisualStyleBackColor = false;
            this.plusmin.Click += new System.EventHandler(this.plusmin_click);
            // 
            // Kalkulator
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.ClientSize = new System.Drawing.Size(308, 414);
            this.Controls.Add(this.plusmin);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.num6);
            this.Controls.Add(this.Display);
            this.Controls.Add(this.delete);
            this.Controls.Add(this.hapus1);
            this.Controls.Add(this.bagi);
            this.Controls.Add(this.kali);
            this.Controls.Add(this.kurang);
            this.Controls.Add(this.plus);
            this.Controls.Add(this.hasil);
            this.Controls.Add(this.coma);
            this.Controls.Add(this.num0);
            this.Controls.Add(this.num9);
            this.Controls.Add(this.num8);
            this.Controls.Add(this.num7);
            this.Controls.Add(this.num5);
            this.Controls.Add(this.num4);
            this.Controls.Add(this.num3);
            this.Controls.Add(this.num2);
            this.Controls.Add(this.num1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "Kalkulator";
            this.Text = "Kalkulator";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.Click += new System.EventHandler(this.num6_click);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button num1;
        private System.Windows.Forms.Button num2;
        private System.Windows.Forms.Button num3;
        private System.Windows.Forms.Button num4;
        private System.Windows.Forms.Button num5;
        private System.Windows.Forms.Button num7;
        private System.Windows.Forms.Button num8;
        private System.Windows.Forms.Button num9;
        private System.Windows.Forms.Button num0;
        private System.Windows.Forms.Button coma;
        private System.Windows.Forms.Button hasil;
        private System.Windows.Forms.Button plus;
        private System.Windows.Forms.Button kurang;
        private System.Windows.Forms.Button kali;
        private System.Windows.Forms.Button bagi;
        private System.Windows.Forms.Button hapus1;
        private System.Windows.Forms.Button delete;
        private System.Windows.Forms.TextBox Display;
        private System.Windows.Forms.Button num6;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button plusmin;
    }
}

