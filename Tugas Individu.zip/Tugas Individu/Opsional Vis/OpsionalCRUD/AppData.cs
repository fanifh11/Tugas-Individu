﻿namespace OpsionalCRUD
{


    partial class AppData
    {
        partial class memberDataTable
        {
        }
    }
}
